create view vw_getempanddeptandmgrinfo as (select `exam`.`emp`.`empno`    AS `empno`,
                                                  `exam`.`emp`.`ename`    AS `ename`,
                                                  `exam`.`emp`.`job`      AS `job`,
                                                  `exam`.`emp`.`mgr`      AS `mgr`,
                                                  `exam`.`emp`.`hiredate` AS `hiredate`,
                                                  `exam`.`emp`.`sal`      AS `sal`,
                                                  `exam`.`emp`.`COMM`     AS `COMM`,
                                                  `exam`.`emp`.`deptno`   AS `deptno`,
                                                  `exam`.`dept`.`dname`   AS `dname`,
                                                  `exam`.`dept`.`loc`     AS `loc`,
                                                  `leader`.`ename`        AS `mgrName`
                                           from ((`exam`.`emp` left join `exam`.`dept` on ((`exam`.`emp`.`deptno` =
                                                                                            `exam`.`dept`.`deptno`))) left join `exam`.`emp` `leader` on ((
                                             `exam`.`emp`.`mgr` = `leader`.`empno`))));

